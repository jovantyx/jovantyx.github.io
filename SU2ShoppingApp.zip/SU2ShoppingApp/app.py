from flask import Flask, render_template, request, redirect, flash, url_for

app = Flask(__name__)
app.secret_key = "lalalala"


items = {
    "item_1":
    {
        "item_id": 1,
        "item_name": "Minty Fresh Blast",
        "item_description": "A powerful mint flavor that leaves your mouth feeling clean and refreshed.",
        "inventory_quantity": 500
    },

    "item_2":
    {
        "item_id": 2,
        "item_name": "Strawberry Swirl",
        "item_description": "Sweet and tangy strawberry flavor with a creamy swirl.",
        "inventory_quantity": 350
    },

    "item_3":
    {
        "item_id": 3,
        "item_name": "Sour Apple Zinger",
        "item_description": "A sharp, sour green apple flavor that makes your taste buds tingle.",
        "inventory_quantity": 275
    },

    "item_4":
    {
        "item_id": 4,
        "item_name": "Bubblegum Pop",
        "item_description": "Classic bubblegum flavor for big, long-lasting bubbles.",
        "inventory_quantity": 600
    },

    "item_5":
    {
        "item_id": 5,
        "item_name": "Watermelon Wave",
        "item_description": "Juicy watermelon flavor that's perfect for a summer day.",
        "inventory_quantity": 420
    },

    "item_6":
    {
        "item_id": 6,
        "item_name": "Tropical Tango",
        "item_description": "A medley of pineapple, mango, and passion fruit flavors.",
        "inventory_quantity": 300
    },

    "item_7":
    {
        "item_id": 7,
        "item_name": "Cinnamon Spark",
        "item_description": "A warm, spicy cinnamon flavor with a hint of sweetness.",
        "inventory_quantity": 450
    },

    "item_8":
    {
        "item_id": 8,
        "item_name": "Berry Burst",
        "item_description": "A vibrant mix of blueberry, raspberry, and blackberry flavors.",
        "inventory_quantity": 380
    },

    "item_9":
    {
        "item_id": 9,
        "item_name": "Peppermint Chill",
        "item_description": "A classic peppermint flavor for a cool, invigorating sensation.",
        "inventory_quantity": 550
    },

    "item_10":
    {
        "item_id": 10,
        "item_name": "Grape Getaway",
        "item_description": "A rich, sweet grape flavor that transports you to a vineyard.",
        "inventory_quantity": 290
    },

    "item_11":
    {
        "item_id": 11,
        "item_name": "Spearmint Spring",
        "item_description": "A gentle and cool spearmint flavor for a smooth chew.",
        "inventory_quantity": 510
    },

    "item_12":
    {
        "item_id": 12,
        "item_name": "Lemon Lime Zing",
        "item_description": "A sharp citrus combination of lemon and lime.",
        "inventory_quantity": 250
    },

    "item_13":
    {
        "item_id": 13,
        "item_name": "Mango Melody",
        "item_description": "The sweet and tropical taste of ripe mangoes.",
        "inventory_quantity": 330
    },

    "item_14":
    {
        "item_id": 14,
        "item_name": "Cherry Cola Fizz",
        "item_description": "A nostalgic soda flavor with a bubbly cherry finish.",
        "inventory_quantity": 220
    },

    "item_15":
    {
        "item_id": 15,
        "item_name": "Blueberry Bliss",
        "item_description": "A pure, sweet blueberry flavor that’s simply delightful.",
        "inventory_quantity": 400
    },

    "item_16":
    {
        "item_id": 16,
        "item_name": "Licorice Twist",
        "item_description": "A unique and bold black licorice flavor.",
        "inventory_quantity": 180
    }
}

cart = []

@app.route("/")

@app.route("/shop", methods=["GET"])
def shop():
    flash('Special Sale! Buy 20 chewing gum get 50% off! What are you waiting for?', 'info')
    return render_template("shop.html", items=items)


@app.route("/shop/<int:item_id>", methods=["GET"])
def show_item(item_id):
    item = items.get(f"item_{item_id}")
    return render_template("item.html", item=item)

@app.route("/cart", methods=["GET", "POST"])
def handle_cart():

    return redirect(url_for("shop"))
  
